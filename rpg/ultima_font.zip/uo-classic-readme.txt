UO Classic (rough) by Zym Dragon

This font was created by taking screen-shots of text in UO's classic client.
It's rough due to the nature of the font in game as it is a pixel by
pixel representaion of the font.

Free free to use this font with credits.

ver 0.2 - 2010-05-25